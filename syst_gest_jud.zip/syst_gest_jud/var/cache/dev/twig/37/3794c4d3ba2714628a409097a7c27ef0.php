<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* signin_signup_page.html.twig */
class __TwigTemplate_1c030e640f2c3fdea43664e3894c4bb0 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "signin_signup_page.html.twig"));

        // line 1
        yield "<!DOCTYPE html>
<html lang=\"en\" >
<head>
  <meta charset=\"UTF-8\">
  <title>Signin</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css'><link rel=\"stylesheet\" href=\"./style.css\">
  <link rel=\"stylesheet\" href=\"";
        // line 7
        yield Twig\Extension\EscaperExtension::escape($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/signin.css"), "html", null, true);
        yield "\">

</head>
<body>
<!-- partial:index.partial.html -->

<div class=\"container\" id=\"container\">
\t<div class=\"form-container sign-up-container\">
\t\t<form  method=\"post\" action=\"";
        // line 15
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\">
\t\t\t<h1>Create Account</h1>
\t\t\t<select name=\"role\">
\t\t\t\t<option class=\"option\" value=\"lawyer\">lawyer</option>
\t\t\t\t<option class=\"option\" value=\"audiance\">audiance</option>
\t\t\t\t<option class=\"option\" value=\"jugde\">judge</option>
\t\t\t</select>
\t\t\t<input id=\"name\" name=\"name\" type=\"text\" placeholder=\"Name\" />
\t\t\t<input id=\"email\" name=\"email\" type=\"email\" placeholder=\"Email\" />
\t\t\t<input id=\"password\" name=\"password\" type=\"password\" placeholder=\"Password\" />
\t\t\t<input id=\"confirmpassword\" name=\"confirmpassword\" type=\"password\" placeholder=\"Confirm Password\" />
\t\t\t<button>Sign Up</button>
\t\t</form>
\t</div>
\t<div class=\"form-container sign-in-container\">
\t\t<form action=\"#\">
\t\t\t<h1>Sign in</h1>
\t\t\t<input type=\"email\" placeholder=\"Email\" />
\t\t\t<input type=\"password\" placeholder=\"Password\" />
\t\t\t<a href=\"#\">Forgot your password?</a>
\t\t\t<button>Sign In</button>
\t\t</form>
\t</div>
\t<div class=\"overlay-container\">
\t\t<div class=\"overlay\">
\t\t\t<div class=\"overlay-panel overlay-left\">
\t\t\t\t<h1>Welcome Back!</h1>
\t\t\t\t<p>To keep connected with us please login with your personal info</p>
\t\t\t\t<button class=\"ghost\" id=\"signIn\">Sign In</button>
\t\t\t</div>
\t\t\t<div class=\"overlay-panel overlay-right\">
\t\t\t\t<h1>Dont have an account?</h1>
\t\t\t\t<p>Enter your personal details and start journey with us</p>
\t\t\t\t<button class=\"ghost\" id=\"signUp\">Sign Up</button>
\t\t\t</div>
\t\t</div>
\t</div>
</div>


  <script  >
  const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

signUpButton.addEventListener('click', () => {
\tcontainer.classList.add(\"right-panel-active\");
});

signInButton.addEventListener('click', () => {
\tcontainer.classList.remove(\"right-panel-active\");
});
  </script>

</body>
</html>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "signin_signup_page.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  60 => 15,  49 => 7,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\" >
<head>
  <meta charset=\"UTF-8\">
  <title>Signin</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css'><link rel=\"stylesheet\" href=\"./style.css\">
  <link rel=\"stylesheet\" href=\"{{ asset('css/signin.css') }}\">

</head>
<body>
<!-- partial:index.partial.html -->

<div class=\"container\" id=\"container\">
\t<div class=\"form-container sign-up-container\">
\t\t<form  method=\"post\" action=\"{{ path('signup') }}\">
\t\t\t<h1>Create Account</h1>
\t\t\t<select name=\"role\">
\t\t\t\t<option class=\"option\" value=\"lawyer\">lawyer</option>
\t\t\t\t<option class=\"option\" value=\"audiance\">audiance</option>
\t\t\t\t<option class=\"option\" value=\"jugde\">judge</option>
\t\t\t</select>
\t\t\t<input id=\"name\" name=\"name\" type=\"text\" placeholder=\"Name\" />
\t\t\t<input id=\"email\" name=\"email\" type=\"email\" placeholder=\"Email\" />
\t\t\t<input id=\"password\" name=\"password\" type=\"password\" placeholder=\"Password\" />
\t\t\t<input id=\"confirmpassword\" name=\"confirmpassword\" type=\"password\" placeholder=\"Confirm Password\" />
\t\t\t<button>Sign Up</button>
\t\t</form>
\t</div>
\t<div class=\"form-container sign-in-container\">
\t\t<form action=\"#\">
\t\t\t<h1>Sign in</h1>
\t\t\t<input type=\"email\" placeholder=\"Email\" />
\t\t\t<input type=\"password\" placeholder=\"Password\" />
\t\t\t<a href=\"#\">Forgot your password?</a>
\t\t\t<button>Sign In</button>
\t\t</form>
\t</div>
\t<div class=\"overlay-container\">
\t\t<div class=\"overlay\">
\t\t\t<div class=\"overlay-panel overlay-left\">
\t\t\t\t<h1>Welcome Back!</h1>
\t\t\t\t<p>To keep connected with us please login with your personal info</p>
\t\t\t\t<button class=\"ghost\" id=\"signIn\">Sign In</button>
\t\t\t</div>
\t\t\t<div class=\"overlay-panel overlay-right\">
\t\t\t\t<h1>Dont have an account?</h1>
\t\t\t\t<p>Enter your personal details and start journey with us</p>
\t\t\t\t<button class=\"ghost\" id=\"signUp\">Sign Up</button>
\t\t\t</div>
\t\t</div>
\t</div>
</div>


  <script  >
  const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

signUpButton.addEventListener('click', () => {
\tcontainer.classList.add(\"right-panel-active\");
});

signInButton.addEventListener('click', () => {
\tcontainer.classList.remove(\"right-panel-active\");
});
  </script>

</body>
</html>
", "signin_signup_page.html.twig", "S:\\php puta\\syst_gest_jud\\templates\\signin_signup_page.html.twig");
    }
}
